exports.ids = [0];
exports.modules = {

/***/ "./components/CatProductsRow/CatProductsRow.js":
/*!*****************************************************!*\
  !*** ./components/CatProductsRow/CatProductsRow.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/json/stringify */ "./node_modules/@babel/runtime-corejs2/core-js/json/stringify.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var _Category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Category */ "./components/CatProductsRow/Category.js");
/* harmony import */ var _Sort__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Sort */ "./components/CatProductsRow/Sort.js");
/* harmony import */ var _Product__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Product */ "./components/CatProductsRow/Product.js");
/* harmony import */ var _utils_fetchData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/fetchData */ "./utils/fetchData.js");
/* harmony import */ var _Loader_Loading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Loader/Loading */ "./components/Loader/Loading.js");
/* harmony import */ var _scss_components_catProductsRow_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../scss/components/catProductsRow.scss */ "./scss/components/catProductsRow.scss");
/* harmony import */ var _scss_components_catProductsRow_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_scss_components_catProductsRow_scss__WEBPACK_IMPORTED_MODULE_8__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;









const CatProductsRow = props => {
  const {
    0: products,
    1: setProducts
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(props.products);
  const {
    0: sortFilter,
    1: setSortFilter
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])('New');

  const handleSort = sortType => {
    setSortFilter(sortType);
  };

  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);

  const getProducts = async () => {
    setLoading(true);
    let GetMarketAround = await Object(_utils_fetchData__WEBPACK_IMPORTED_MODULE_6__["default"])('User/U_Product/GetMarketAround', {
      method: 'POST',
      body: _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_0___default()({
        filters: sortFilter,
        categoryId: 1,
        page: 1,
        pageSize: 10
      })
    }, props.ctx);

    if (GetMarketAround !== undefined && GetMarketAround.isSuccess) {
      let products = GetMarketAround.data || [];
      setProducts(products);
    } else if (GetMarketAround !== undefined && GetMarketAround.message != undefined) {//toast.warn(GetMarketAround.message);
    } else if (GetMarketAround !== undefined && GetMarketAround.error != undefined) {//toast.error(GetMarketAround.error);
    }

    setLoading(false);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    getProducts();
  }, [sortFilter]);

  const renderProducts = () => {
    if (loading) {
      return __jsx("div", {
        style: {
          display: 'block !important',
          width: '100%',
          height: '40px',
          textAlign: 'center'
        }
      }, __jsx(_Loader_Loading__WEBPACK_IMPORTED_MODULE_7__["default"], null));
    } else {
      const productsElements = products.map(product => {
        const productThumbNail = product.pictures[0] != undefined ? `https://api.qarun.ir/${product.pictures[0].thumbNail}` : '/static/img/no-product-image.png';
        return __jsx(_Product__WEBPACK_IMPORTED_MODULE_5__["default"], {
          key: product.id,
          id: product.id,
          productName: product.title,
          price: product.lastPrice,
          oldPrice: product.price,
          image: productThumbNail,
          userId: product.sellerUserName,
          sellerAvatar: `https://api.qarun.ir/${product.sellerAvatar}`,
          sellerUserName: product.sellerUserName
        });
      });
      return productsElements;
    }
  }; // products.map(product => {
  //   const productThumbNail = product.pictures[0] != undefined ? `https://api.qarun.ir/${product.pictures[0].thumbNail}` : '/static/img/no-product-image.png';
  //   if (loading) {
  //     return <Loading />;
  //   } else {
  //     return (
  //       <Product
  //         key={product.id}
  //         id={product.id}
  //         productName={product.title}
  //         price={product.price}
  //         oldPrice={product.lastPrice}
  //         image={productThumbNail}
  //         userId={product.sellerUserName}
  //         sellerAvatar={`https://api.qarun.ir/${product.sellerAvatar}`}
  //         sellerUserName={product.sellerUserName}
  //       />
  //     );
  //   }
  // });


  return __jsx("div", {
    className: "container mb-1 cat_product_row"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col"
  }, __jsx("div", {
    className: "row d-flex justify-content-center rtl pr-2 mb-1 cat_sort"
  }, __jsx(_Sort__WEBPACK_IMPORTED_MODULE_4__["default"], {
    handleSort: handleSort
  })), __jsx("div", {
    className: "row d-flex justify-content-start rtl products"
  }, renderProducts()))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(CatProductsRow));

/***/ }),

/***/ "./components/CatProductsRow/Category.js":
/*!***********************************************!*\
  !*** ./components/CatProductsRow/Category.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/io */ "react-icons/io");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
/* harmony import */ var _scss_components_categoriesRow_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../scss/components/categoriesRow.scss */ "./scss/components/categoriesRow.scss");
/* harmony import */ var _scss_components_categoriesRow_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scss_components_categoriesRow_scss__WEBPACK_IMPORTED_MODULE_4__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;






const Category = props => {
  const width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_3__["default"])();

  const renderCatLi = () => {
    // If Windows.Width < 992 (large) just show 5 coulmn users else show 11 users
    // if (width < 992) {
    //   return (
    //     <>
    //       <li className="nav-item">
    //         <Link href="/category/" passHref>
    //           <a className="nav-link active">سوپر مارکت</a>
    //         </Link>
    //       </li>
    //       <li className="nav-item">
    //         <Link href="/category/" passHref>
    //           <a className="nav-link">رستوران و فست فود</a>
    //         </Link>
    //       </li>
    //       <li className="nav-item">
    //         <Link href="/category/" passHref>
    //           <a className="nav-link">نان و شیرینی</a>
    //         </Link>
    //       </li>
    //     </>
    //   );
    // } else {
    return __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link active"
    }, "\u0633\u0648\u067E\u0631 \u0645\u0627\u0631\u06A9\u062A"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0631\u0633\u062A\u0648\u0631\u0627\u0646 \u0648 \u0641\u0633\u062A \u0641\u0648\u062F"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0646\u0627\u0646 \u0648 \u0634\u06CC\u0631\u06CC\u0646\u06CC"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0633\u0648\u067E\u0631 \u0645\u0627\u0631\u06A9\u062A"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0631\u0633\u062A\u0648\u0631\u0627\u0646 \u0648 \u0641\u0633\u062A \u0641\u0648\u062F"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0646\u0627\u0646 \u0648 \u0634\u06CC\u0631\u06CC\u0646\u06CC"))), __jsx("li", {
      className: "nav-item"
    }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
      href: "/category/",
      passHref: true
    }, __jsx("a", {
      className: "nav-link"
    }, "\u0633\u0648\u067E\u0631 \u0645\u0627\u0631\u06A9\u062A")))); // }
  };

  return __jsx("ul", {
    className: "nav"
  }, renderCatLi(), __jsx("li", {
    className: "nav-item"
  }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: "/categories",
    passHref: true
  }, __jsx("a", {
    className: "more nav-link"
  }, __jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_2__["IoIosMore"], null)))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Category));

/***/ }),

/***/ "./components/CatProductsRow/Product.js":
/*!**********************************************!*\
  !*** ./components/CatProductsRow/Product.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/fa */ "react-icons/fa");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
/* harmony import */ var _utils_tools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/tools */ "./utils/tools.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;






const Product = props => {
  return __jsx("div", {
    className: "col-4 col-lg-2 product"
  }, __jsx("div", {
    className: "product_frame"
  }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: `/product/${props.id}`,
    passHref: true
  }, __jsx("a", {
    className: "product_link"
  }, __jsx("img", {
    src: props.image,
    alt: props.productName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_basket",
    id: props.id
  }, __jsx("p", null, "\u0633\u0628\u062F \u062E\u0631\u06CC\u062F"), __jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__["FaShoppingBasket"], {
    className: "svg_Icons"
  })), __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: `/user/${props.sellerUserName}`,
    passHref: true
  }, __jsx("a", {
    className: "product_user"
  }, __jsx("img", {
    src: props.sellerAvatar,
    alt: props.sellerUserName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_text mb-1"
  }, __jsx("p", null, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.price), " "), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")), props.oldPrice && __jsx("p", {
    className: "price_old"
  }, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.oldPrice)), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Product));

/***/ }),

/***/ "./components/CatProductsRow/Sort.js":
/*!*******************************************!*\
  !*** ./components/CatProductsRow/Sort.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



const Sort = props => {
  const handleSort = props.handleSort;
  const {
    0: sorts,
    1: setSorts
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([{
    id: 0,
    name: 'تازه',
    filter: 'New',
    active: true
  }, {
    id: 1,
    name: 'محبوب',
    filter: 'Popular',
    active: false
  }, {
    id: 2,
    name: 'پرفروش',
    filter: 'BestSeller',
    active: false
  }, {
    id: 3,
    name: 'تخفیف دار',
    filter: 'Discount',
    active: false
  }, {
    id: 4,
    name: 'فعال',
    filter: 'NotSet',
    active: false
  }]);

  const toggleActiveSort = index => {
    sorts[index];
    const sortObject = sorts.filter(s => sorts.indexOf(s) == index)[0];
    sortObject.active = true;
    const otherSortObject = sorts.filter(s => sorts.indexOf(s) !== index).map(s => {
      s.active = false;
      return s;
    });
    const all = otherSortObject.concat(sortObject).sort((a, b) => a.id - b.id);
    setSorts(all);
  };

  const showSorts = sorts.map(sort => {
    let classN = sort.active ? 'nav-link active' : 'nav-link';
    return __jsx("li", {
      key: sort.id,
      className: "nav-item"
    }, __jsx("a", {
      className: classN,
      onClick: () => {
        handleSort(sort.filter);
        toggleActiveSort(sort.id);
      }
    }, sort.name));
  });
  return __jsx("ul", {
    className: "nav"
  }, showSorts);
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Sort));

/***/ }),

/***/ "./components/WindowsWidth.js":
/*!************************************!*\
  !*** ./components/WindowsWidth.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (() => {
  const {
    0: width,
    1: setWidth
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined);

  const handleResize = () => setWidth(window.innerWidth);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    window.addEventListener('resize', handleResize);
    setWidth(window.innerWidth);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });
  return width;
});

/***/ }),

/***/ "./scss/components/catProductsRow.scss":
/*!*********************************************!*\
  !*** ./scss/components/catProductsRow.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./scss/components/categoriesRow.scss":
/*!********************************************!*\
  !*** ./scss/components/categoriesRow.scss ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./utils/tools.js":
/*!************************!*\
  !*** ./utils/tools.js ***!
  \************************/
/*! exports provided: objectifyForm, isJSON, numberSeparator, removeSeparator, forceNumeric, forceNumeric4, forceNumeric6, forceNumeric10, fixNumbers, convertNumber, checkPersianWord, forceLetter, secondsToMs, getDistance, EMAIL_RX, Mobile_RX, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "objectifyForm", function() { return objectifyForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isJSON", function() { return isJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "numberSeparator", function() { return numberSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeSeparator", function() { return removeSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric", function() { return forceNumeric; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric4", function() { return forceNumeric4; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric6", function() { return forceNumeric6; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric10", function() { return forceNumeric10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fixNumbers", function() { return fixNumbers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertNumber", function() { return convertNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkPersianWord", function() { return checkPersianWord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceLetter", function() { return forceLetter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "secondsToMs", function() { return secondsToMs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDistance", function() { return getDistance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_RX", function() { return EMAIL_RX; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Mobile_RX", function() { return Mobile_RX; });
// Convert Form Array To json
const objectifyForm = formArray => {
  //serialize data function
  let returnArray = {};

  for (var i = 0; i < formArray.length; i++) {
    returnArray[formArray[i]['name']] = formArray[i]['value'];
  }

  return returnArray;
}; // Check string is json or not

const isJSON = str => {
  try {
    return JSON.parse(str) && !!str;
  } catch (e) {
    return false;
  }
}; // Add comma Separator to digit number

const numberSeparator = (num, sep) => {
  let number = removeSeparator(num).toString(),
      separator = typeof sep === 'undefined' ? ',' : sep;
  return number.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + separator);
}; // Remove comma seprator From digit number

const removeSeparator = (num, sep) => {
  let separator = typeof sep === 'undefined' ? ',' : sep;
  var re = new RegExp(separator, 'g');
  return num.toString().replace(re, '');
}; // Convert elemetn's value for remove all characters exept number, Just Allow Type Numbers

const forceNumeric = e => {
  //let $input = e.replace(/[^\d]+/g, '');
  let $input = e.replace(/[^0-9۰-۹]+/g, '');
  return $input;
}; // Just Allow 4 number

const forceNumeric4 = e => {
  let $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 4) {
    $input = $input.substring(0, 4);
  }

  return $input;
}; // Just Allow 6 number

const forceNumeric6 = e => {
  let $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 6) {
    $input = $input.substring(0, 6);
  }

  return $input;
}; // Just Allow 10 number

const forceNumeric10 = e => {
  var $input = e;
  $input.replace(/[^\d]+/g, '');

  if ($input.length > 10) {
    $input = $input.substring(0, 10);
  }

  return $input;
}; // Convert Persian & Arabic number to English

const persianNumbersExp = [/۰/g, /۱/g, /۲/g, /۳/g, /۴/g, /۵/g, /۶/g, /۷/g, /۸/g, /۹/g];
const arabicNumbersExp = [/٠/g, /١/g, /٢/g, /٣/g, /٤/g, /٥/g, /٦/g, /٧/g, /٨/g, /٩/g];
const englishNumbersExp = [/0/g, /1/g, /2/g, /3/g, /4/g, /5/g, /6/g, /7/g, /8/g, /9/g];
const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fixNumbers = str => {
  str = str.toString();

  if (typeof str === 'string') {
    for (let i = 0; i < 10; i++) {
      str = str.replace(persianNumbersExp[i], i).replace(arabicNumbersExp[i], i);
    }
  }

  return str;
}; // Convert  English number to Persian

const convertNumber = str => {
  str = str.toString();

  if (typeof str === 'string') {
    for (let i = 0; i < 10; i++) {
      str = str.replace(englishNumbersExp[i], persianNumbers[i]);
    }
  }

  return str;
}; // Check if value Start (^) with a Persian word

const checkPersianWord = string => {
  if (!/^[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤإأءًٌٍَُِّ\s\n\r\t\d\(\)\[\]\{\}.,،;\-؛]+$/.test(string)) {//console.log('با کلمه فارسی شروع نشده');
  } else {//console.log('با کلمه فارسی شروع شده');
    }
}; // Don't Allow Specials Characters and numbers to type and replace them with remove, Work Fine

const forceLetter = e => {
  let $input = e;
  $input.replace(/\d/g, '');
  $input.replace(/[&\/\\#,@@|+=!-_()$~%.'":*؟،×÷?<>{}]/g, ''); //$input.replace(/\s/g,'');       // space

  return $input;
}; // Convert Second to M:S

const secondsToMs = d => {
  d = Number(d);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);
  var mDisplay = m > 0 ? m + ':' : '00:';
  var sDisplay = s > 0 ? s : '00';
  return mDisplay + sDisplay;
}; // Calculate distance between 2 GPS coordinates in kilometer

const getDistance = (lat1, lon1, lat2, lon2) => {
  const degreesToRadians = degrees => degrees * Math.PI / 180;

  let earthRadiusKm = 6371;
  let dLat = degreesToRadians(lat2 - lat1);
  let dLon = degreesToRadians(lon2 - lon1);
  lat1 = degreesToRadians(lat1);
  lat2 = degreesToRadians(lat2);
  let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return earthRadiusKm * c;
}; // Email Validation Regex

const EMAIL_RX = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,64}/; // Moible Validation Regex

const Mobile_RX = /(\+98|0|98|0098)?([ ]|-|[()]){0,2}9[0-9]([ ]|-|[()]){0,2}(?:[0-9]([ ]|-|[()]){0,2}){8}/;
/* harmony default export */ __webpack_exports__["default"] = (numberSeparator);

/***/ })

};;
//# sourceMappingURL=0.js.map