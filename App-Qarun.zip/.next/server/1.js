exports.ids = [1];
exports.modules = {

/***/ "./components/ProductRow/Product.js":
/*!******************************************!*\
  !*** ./components/ProductRow/Product.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/fa */ "react-icons/fa");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
/* harmony import */ var _utils_tools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/tools */ "./utils/tools.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;






const Product = props => {
  const width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_3__["default"])();

  const productClass = () => {
    // If Windows.Width < 992 (large) just show 5 coulmn users else show 11 users
    if (width > 1442) {
      return 'col-6 col-lg-3 col-xl-2 product';
    } else {
      return 'col-6 col-lg-3 product';
    }
  };

  return __jsx("div", {
    className: productClass()
  }, __jsx("div", {
    className: "product_frame"
  }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: `/product/${props.id}`,
    passHref: true
  }, __jsx("a", {
    className: "product_link"
  }, __jsx("img", {
    src: props.image,
    alt: props.productName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_basket",
    id: props.id
  }, __jsx("p", null, "\u0633\u0628\u062F \u062E\u0631\u06CC\u062F"), __jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__["FaShoppingBasket"], {
    className: "svg_Icons"
  })), __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: `/user/${props.sellerUserName}`,
    passHref: true
  }, __jsx("a", {
    className: "product_user"
  }, __jsx("img", {
    src: props.sellerAvatar,
    alt: props.sellerUserName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_text"
  }, __jsx("p", null, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.price), " "), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")), props.oldPrice && __jsx("p", {
    className: "price_old"
  }, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.oldPrice)), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Product));

/***/ }),

/***/ "./components/ProductRow/ProductRow.js":
/*!*********************************************!*\
  !*** ./components/ProductRow/ProductRow.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/map */ "./node_modules/@babel/runtime-corejs2/core-js/map.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/json/stringify */ "./node_modules/@babel/runtime-corejs2/core-js/json/stringify.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var _Product__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Product */ "./components/ProductRow/Product.js");
/* harmony import */ var _utils_fetchData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/fetchData */ "./utils/fetchData.js");
/* harmony import */ var _Loader_Loading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Loader/Loading */ "./components/Loader/Loading.js");
/* harmony import */ var _scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../scss/components/productRow.scss */ "./scss/components/productRow.scss");
/* harmony import */ var _scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_7__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement;







const ProductsRow = props => {
  const {
    0: products,
    1: setProducts
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(props.products);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: page,
    1: setPage
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(2);
  const {
    0: isFetching,
    1: setIsFetching
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);

  const getProducts = async () => {
    setLoading(true);
    const FriendsMarket = await Object(_utils_fetchData__WEBPACK_IMPORTED_MODULE_5__["default"])('User/U_Product/FriendsMarket', {
      method: 'POST',
      body: _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_1___default()({
        page: page,
        pageSize: 6
      })
    }, props.ctx);

    if (FriendsMarket.isSuccess) {
      let newProducts = FriendsMarket.data || [];
      const p = products.concat(newProducts); // Remove duplicate products in array with id

      const result = [];
      const map = new _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_0___default.a();

      for (const item of p) {
        if (!map.has(item.id)) {
          map.set(item.id, true); // set any value to Map

          result.push(item);
        }
      }

      setProducts(result);
      setTimeout(() => setIsFetching(false), 200);

      if (newProducts.length >= 6) {
        setPage(page + 1);
      }
    } else if (FriendsMarket.message != undefined) {
      setTimeout(() => setIsFetching(false), 200);
    } else if (FriendsMarket.error != undefined) {
      setTimeout(() => setIsFetching(false), 200);
    }

    setLoading(false);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    if (!isFetching) return;
    getProducts();
  }, [isFetching]);

  function handleScroll() {
    if (window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight || isFetching) return; // console.log(page)
    // setPage(page + 1);

    setIsFetching(true); // if (window.pageYOffset > window.innerHeight && !isFetching) {
    //   setIsFetching(true);
    // } else {
    //   return;
    // }
  }

  const renderProducts = products.map(product => {
    const productThumbNail = product.pictures[0] != undefined ? `https://api.qarun.ir/${product.pictures[0].thumbNail}` : '/static/img/no-product-image.png';
    return __jsx(_Product__WEBPACK_IMPORTED_MODULE_4__["default"], {
      key: product.id,
      id: product.id,
      productName: product.title,
      price: product.lastPrice,
      oldPrice: product.price,
      image: productThumbNail,
      userId: product.sellerUserName,
      sellerAvatar: `https://api.qarun.ir/${product.sellerAvatar}`,
      sellerUserName: product.sellerUserName
    });
  });
  return __jsx("div", {
    className: "container mt-1 mb-5 pb-5"
  }, __jsx("div", {
    className: "row rtl product_row"
  }, renderProducts, loading && __jsx("div", {
    style: {
      display: 'block !important',
      width: '100%',
      height: '40px',
      textAlign: 'center',
      marginTop: '0.1rem'
    }
  }, __jsx(_Loader_Loading__WEBPACK_IMPORTED_MODULE_6__["default"], null))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_2__["memo"])(ProductsRow));

/***/ }),

/***/ "./components/WindowsWidth.js":
/*!************************************!*\
  !*** ./components/WindowsWidth.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (() => {
  const {
    0: width,
    1: setWidth
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined);

  const handleResize = () => setWidth(window.innerWidth);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    window.addEventListener('resize', handleResize);
    setWidth(window.innerWidth);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });
  return width;
});

/***/ }),

/***/ "./scss/components/productRow.scss":
/*!*****************************************!*\
  !*** ./scss/components/productRow.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./utils/tools.js":
/*!************************!*\
  !*** ./utils/tools.js ***!
  \************************/
/*! exports provided: objectifyForm, isJSON, numberSeparator, removeSeparator, forceNumeric, forceNumeric4, forceNumeric6, forceNumeric10, fixNumbers, convertNumber, checkPersianWord, forceLetter, secondsToMs, getDistance, EMAIL_RX, Mobile_RX, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "objectifyForm", function() { return objectifyForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isJSON", function() { return isJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "numberSeparator", function() { return numberSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeSeparator", function() { return removeSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric", function() { return forceNumeric; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric4", function() { return forceNumeric4; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric6", function() { return forceNumeric6; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric10", function() { return forceNumeric10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fixNumbers", function() { return fixNumbers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertNumber", function() { return convertNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkPersianWord", function() { return checkPersianWord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceLetter", function() { return forceLetter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "secondsToMs", function() { return secondsToMs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDistance", function() { return getDistance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_RX", function() { return EMAIL_RX; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Mobile_RX", function() { return Mobile_RX; });
// Convert Form Array To json
const objectifyForm = formArray => {
  //serialize data function
  let returnArray = {};

  for (var i = 0; i < formArray.length; i++) {
    returnArray[formArray[i]['name']] = formArray[i]['value'];
  }

  return returnArray;
}; // Check string is json or not

const isJSON = str => {
  try {
    return JSON.parse(str) && !!str;
  } catch (e) {
    return false;
  }
}; // Add comma Separator to digit number

const numberSeparator = (num, sep) => {
  let number = removeSeparator(num).toString(),
      separator = typeof sep === 'undefined' ? ',' : sep;
  return number.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + separator);
}; // Remove comma seprator From digit number

const removeSeparator = (num, sep) => {
  let separator = typeof sep === 'undefined' ? ',' : sep;
  var re = new RegExp(separator, 'g');
  return num.toString().replace(re, '');
}; // Convert elemetn's value for remove all characters exept number, Just Allow Type Numbers

const forceNumeric = e => {
  //let $input = e.replace(/[^\d]+/g, '');
  let $input = e.replace(/[^0-9۰-۹]+/g, '');
  return $input;
}; // Just Allow 4 number

const forceNumeric4 = e => {
  let $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 4) {
    $input = $input.substring(0, 4);
  }

  return $input;
}; // Just Allow 6 number

const forceNumeric6 = e => {
  let $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 6) {
    $input = $input.substring(0, 6);
  }

  return $input;
}; // Just Allow 10 number

const forceNumeric10 = e => {
  var $input = e;
  $input.replace(/[^\d]+/g, '');

  if ($input.length > 10) {
    $input = $input.substring(0, 10);
  }

  return $input;
}; // Convert Persian & Arabic number to English

const persianNumbersExp = [/۰/g, /۱/g, /۲/g, /۳/g, /۴/g, /۵/g, /۶/g, /۷/g, /۸/g, /۹/g];
const arabicNumbersExp = [/٠/g, /١/g, /٢/g, /٣/g, /٤/g, /٥/g, /٦/g, /٧/g, /٨/g, /٩/g];
const englishNumbersExp = [/0/g, /1/g, /2/g, /3/g, /4/g, /5/g, /6/g, /7/g, /8/g, /9/g];
const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fixNumbers = str => {
  str = str.toString();

  if (typeof str === 'string') {
    for (let i = 0; i < 10; i++) {
      str = str.replace(persianNumbersExp[i], i).replace(arabicNumbersExp[i], i);
    }
  }

  return str;
}; // Convert  English number to Persian

const convertNumber = str => {
  str = str.toString();

  if (typeof str === 'string') {
    for (let i = 0; i < 10; i++) {
      str = str.replace(englishNumbersExp[i], persianNumbers[i]);
    }
  }

  return str;
}; // Check if value Start (^) with a Persian word

const checkPersianWord = string => {
  if (!/^[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤإأءًٌٍَُِّ\s\n\r\t\d\(\)\[\]\{\}.,،;\-؛]+$/.test(string)) {//console.log('با کلمه فارسی شروع نشده');
  } else {//console.log('با کلمه فارسی شروع شده');
    }
}; // Don't Allow Specials Characters and numbers to type and replace them with remove, Work Fine

const forceLetter = e => {
  let $input = e;
  $input.replace(/\d/g, '');
  $input.replace(/[&\/\\#,@@|+=!-_()$~%.'":*؟،×÷?<>{}]/g, ''); //$input.replace(/\s/g,'');       // space

  return $input;
}; // Convert Second to M:S

const secondsToMs = d => {
  d = Number(d);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);
  var mDisplay = m > 0 ? m + ':' : '00:';
  var sDisplay = s > 0 ? s : '00';
  return mDisplay + sDisplay;
}; // Calculate distance between 2 GPS coordinates in kilometer

const getDistance = (lat1, lon1, lat2, lon2) => {
  const degreesToRadians = degrees => degrees * Math.PI / 180;

  let earthRadiusKm = 6371;
  let dLat = degreesToRadians(lat2 - lat1);
  let dLon = degreesToRadians(lon2 - lon1);
  lat1 = degreesToRadians(lat1);
  lat2 = degreesToRadians(lat2);
  let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return earthRadiusKm * c;
}; // Email Validation Regex

const EMAIL_RX = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,64}/; // Moible Validation Regex

const Mobile_RX = /(\+98|0|98|0098)?([ ]|-|[()]){0,2}9[0-9]([ ]|-|[()]){0,2}(?:[0-9]([ ]|-|[()]){0,2}){8}/;
/* harmony default export */ __webpack_exports__["default"] = (numberSeparator);

/***/ })

};;
//# sourceMappingURL=1.js.map