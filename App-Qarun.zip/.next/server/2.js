exports.ids = [2];
exports.modules = {

/***/ "./components/UserSuggest/User.js":
/*!****************************************!*\
  !*** ./components/UserSuggest/User.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




const User = props => {
  const width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_2__["default"])();
  const userClass = width > 992 ? 'col-1' : width > 400 ? 'col-2' : 'col-3';
  return __jsx("div", {
    className: 'userClass'
  }, __jsx(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
    href: `/user/${props.userName}`,
    passHref: true
  }, __jsx("a", {
    className: "mr-2 user_link"
  }, __jsx("img", {
    src: props.image,
    alt: props.alt,
    className: "rounded-circle img-thumbnail"
  }))), __jsx("p", {
    className: "user_Suggest_name text-truncate"
  }, props.userName));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(User));

/***/ }),

/***/ "./components/UserSuggest/UserSuggest.js":
/*!***********************************************!*\
  !*** ./components/UserSuggest/UserSuggest.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _User__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./User */ "./components/UserSuggest/User.js");
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/io */ "react-icons/io");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../context/index */ "./context/index.js");
/* harmony import */ var _scss_components_userSuggest_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../scss/components/userSuggest.scss */ "./scss/components/userSuggest.scss");
/* harmony import */ var _scss_components_userSuggest_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_scss_components_userSuggest_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-icons/fi */ "react-icons/fi");
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;









const UserSuggest = props => {
  const users = props.users;
  const width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_3__["default"])();
  const userClass = width > 992 ? 'col-1' : 'col-3';
  const res = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(_context_index__WEBPACK_IMPORTED_MODULE_5__["default"]);
  const renderUsers = users.map(user => __jsx(_User__WEBPACK_IMPORTED_MODULE_1__["default"], {
    key: user.id,
    id: user.id,
    userName: user.userName,
    alt: user.displayName,
    image: `https://api.qarun.ir/${user.userAvatar}`
  }));
  return __jsx("div", {
    className: "container user_Suggestion"
  }, __jsx("div", {
    className: "row"
  }, __jsx("div", {
    className: "col pt-1"
  }, __jsx("div", {
    className: "d-flex justify-content-start rtl over_flow"
  }, renderUsers))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(UserSuggest));

/***/ }),

/***/ "./components/WindowsWidth.js":
/*!************************************!*\
  !*** ./components/WindowsWidth.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (() => {
  const {
    0: width,
    1: setWidth
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined);

  const handleResize = () => setWidth(window.innerWidth);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    window.addEventListener('resize', handleResize);
    setWidth(window.innerWidth);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  });
  return width;
});

/***/ }),

/***/ "./scss/components/userSuggest.scss":
/*!******************************************!*\
  !*** ./scss/components/userSuggest.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ })

};;
//# sourceMappingURL=2.js.map