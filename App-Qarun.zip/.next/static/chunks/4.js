(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./components/Banner/Banner.js":
/*!*************************************!*\
  !*** ./components/Banner/Banner.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



var Banner = function Banner(props) {
  return __jsx("div", {
    className: "col-12 col-lg-6 banner"
  }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: props.link,
    passHref: true
  }, __jsx("a", null, __jsx("img", {
    src: "/static/img/".concat(props.image),
    className: "img-fluid",
    alt: "Responsive image"
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Banner));

/***/ }),

/***/ "./components/Banner/Banners.js":
/*!**************************************!*\
  !*** ./components/Banner/Banners.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var _Banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Banner */ "./components/Banner/Banner.js");
/* harmony import */ var _scss_components_banners_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../scss/components/banners.scss */ "./scss/components/banners.scss");
/* harmony import */ var _scss_components_banners_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_scss_components_banners_scss__WEBPACK_IMPORTED_MODULE_3__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;





var Banners = function Banners() {
  return __jsx("div", {
    className: "container"
  }, __jsx("div", {
    className: "row rtl banners"
  }, __jsx(_Banner__WEBPACK_IMPORTED_MODULE_2__["default"], {
    link: 'bannerLink',
    image: 'Layer30.png'
  }), __jsx(_Banner__WEBPACK_IMPORTED_MODULE_2__["default"], {
    link: 'bannerLink',
    image: 'Layer33.png'
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Banners));

/***/ })

}]);
//# sourceMappingURL=4.js.map