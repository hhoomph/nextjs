(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./components/ProductRow/Product.js":
/*!******************************************!*\
  !*** ./components/ProductRow/Product.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
/* harmony import */ var _utils_tools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/tools */ "./utils/tools.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;






var Product = function Product(props) {
  var width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_3__["default"])();

  var productClass = function productClass() {
    // If Windows.Width < 992 (large) just show 5 coulmn users else show 11 users
    if (width > 1442) {
      return 'col-6 col-lg-3 col-xl-2 product';
    } else {
      return 'col-6 col-lg-3 product';
    }
  };

  return __jsx("div", {
    className: productClass()
  }, __jsx("div", {
    className: "product_frame"
  }, __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: "/product/".concat(props.id),
    passHref: true
  }, __jsx("a", {
    className: "product_link"
  }, __jsx("img", {
    src: props.image,
    alt: props.productName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_basket",
    id: props.id
  }, __jsx("p", null, "\u0633\u0628\u062F \u062E\u0631\u06CC\u062F"), __jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__["FaShoppingBasket"], {
    className: "svg_Icons"
  })), __jsx(_Link__WEBPACK_IMPORTED_MODULE_1__["default"], {
    href: "/user/".concat(props.sellerUserName),
    passHref: true
  }, __jsx("a", {
    className: "product_user"
  }, __jsx("img", {
    src: props.sellerAvatar,
    alt: props.sellerUserName,
    className: "product_img"
  }))), __jsx("div", {
    className: "product_text"
  }, __jsx("p", null, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.price), " "), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")), props.oldPrice && __jsx("p", {
    className: "price_old"
  }, __jsx("span", {
    className: "product_price"
  }, Object(_utils_tools__WEBPACK_IMPORTED_MODULE_4__["numberSeparator"])(props.oldPrice)), __jsx("span", {
    className: "product_currency"
  }, "\u062A\u0648\u0645\u0627\u0646")))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(Product));

/***/ }),

/***/ "./components/ProductRow/ProductRow.js":
/*!*********************************************!*\
  !*** ./components/ProductRow/ProductRow.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_get_iterator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/get-iterator */ "./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_get_iterator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_get_iterator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/map */ "./node_modules/@babel/runtime-corejs2/core-js/map.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/json/stringify */ "./node_modules/@babel/runtime-corejs2/core-js/json/stringify.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Link */ "./components/Link.js");
/* harmony import */ var _Product__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Product */ "./components/ProductRow/Product.js");
/* harmony import */ var _utils_fetchData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/fetchData */ "./utils/fetchData.js");
/* harmony import */ var _Loader_Loading__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Loader/Loading */ "./components/Loader/Loading.js");
/* harmony import */ var _scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../scss/components/productRow.scss */ "./scss/components/productRow.scss");
/* harmony import */ var _scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_scss_components_productRow_scss__WEBPACK_IMPORTED_MODULE_10__);





var __jsx = react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement;







var ProductsRow = function ProductsRow(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(props.products),
      products = _useState[0],
      setProducts = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      loading = _useState2[0],
      setLoading = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(2),
      page = _useState3[0],
      setPage = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(false),
      isFetching = _useState4[0],
      setIsFetching = _useState4[1];

  var getProducts =
  /*#__PURE__*/
  function () {
    var _ref = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])(
    /*#__PURE__*/
    _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      var FriendsMarket, newProducts, p, result, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item;

      return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              setLoading(true);
              _context.next = 3;
              return Object(_utils_fetchData__WEBPACK_IMPORTED_MODULE_8__["default"])('User/U_Product/FriendsMarket', {
                method: 'POST',
                body: _babel_runtime_corejs2_core_js_json_stringify__WEBPACK_IMPORTED_MODULE_3___default()({
                  page: page,
                  pageSize: 6
                })
              }, props.ctx);

            case 3:
              FriendsMarket = _context.sent;

              if (!FriendsMarket.isSuccess) {
                _context.next = 33;
                break;
              }

              newProducts = FriendsMarket.data || [];
              p = products.concat(newProducts); // Remove duplicate products in array with id

              result = [];
              map = new _babel_runtime_corejs2_core_js_map__WEBPACK_IMPORTED_MODULE_2___default.a();
              _iteratorNormalCompletion = true;
              _didIteratorError = false;
              _iteratorError = undefined;
              _context.prev = 12;

              for (_iterator = _babel_runtime_corejs2_core_js_get_iterator__WEBPACK_IMPORTED_MODULE_1___default()(p); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                item = _step.value;

                if (!map.has(item.id)) {
                  map.set(item.id, true); // set any value to Map

                  result.push(item);
                }
              }

              _context.next = 20;
              break;

            case 16:
              _context.prev = 16;
              _context.t0 = _context["catch"](12);
              _didIteratorError = true;
              _iteratorError = _context.t0;

            case 20:
              _context.prev = 20;
              _context.prev = 21;

              if (!_iteratorNormalCompletion && _iterator["return"] != null) {
                _iterator["return"]();
              }

            case 23:
              _context.prev = 23;

              if (!_didIteratorError) {
                _context.next = 26;
                break;
              }

              throw _iteratorError;

            case 26:
              return _context.finish(23);

            case 27:
              return _context.finish(20);

            case 28:
              setProducts(result);
              setTimeout(function () {
                return setIsFetching(false);
              }, 200);

              if (newProducts.length >= 6) {
                setPage(page + 1);
              }

              _context.next = 34;
              break;

            case 33:
              if (FriendsMarket.message != undefined) {
                setTimeout(function () {
                  return setIsFetching(false);
                }, 200);
              } else if (FriendsMarket.error != undefined) {
                setTimeout(function () {
                  return setIsFetching(false);
                }, 200);
              }

            case 34:
              setLoading(false);

            case 35:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[12, 16, 20, 28], [21,, 23, 27]]);
    }));

    return function getProducts() {
      return _ref.apply(this, arguments);
    };
  }();

  Object(react__WEBPACK_IMPORTED_MODULE_5__["useEffect"])(function () {
    window.addEventListener('scroll', handleScroll);
    return function () {
      return window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_5__["useEffect"])(function () {
    if (!isFetching) return;
    getProducts();
  }, [isFetching]);

  function handleScroll() {
    if (window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight || isFetching) return; // console.log(page)
    // setPage(page + 1);

    setIsFetching(true); // if (window.pageYOffset > window.innerHeight && !isFetching) {
    //   setIsFetching(true);
    // } else {
    //   return;
    // }
  }

  var renderProducts = products.map(function (product) {
    var productThumbNail = product.pictures[0] != undefined ? "https://api.qarun.ir/".concat(product.pictures[0].thumbNail) : '/static/img/no-product-image.png';
    return __jsx(_Product__WEBPACK_IMPORTED_MODULE_7__["default"], {
      key: product.id,
      id: product.id,
      productName: product.title,
      price: product.lastPrice,
      oldPrice: product.price,
      image: productThumbNail,
      userId: product.sellerUserName,
      sellerAvatar: "https://api.qarun.ir/".concat(product.sellerAvatar),
      sellerUserName: product.sellerUserName
    });
  });
  return __jsx("div", {
    className: "container mt-1 mb-5 pb-5"
  }, __jsx("div", {
    className: "row rtl product_row"
  }, renderProducts, loading && __jsx("div", {
    style: {
      display: 'block !important',
      width: '100%',
      height: '40px',
      textAlign: 'center',
      marginTop: '0.1rem'
    }
  }, __jsx(_Loader_Loading__WEBPACK_IMPORTED_MODULE_9__["default"], null))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_5__["memo"])(ProductsRow));

/***/ }),

/***/ "./components/WindowsWidth.js":
/*!************************************!*\
  !*** ./components/WindowsWidth.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined),
      width = _useState[0],
      setWidth = _useState[1];

  var handleResize = function handleResize() {
    return setWidth(window.innerWidth);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    window.addEventListener('resize', handleResize);
    setWidth(window.innerWidth);
    return function () {
      window.removeEventListener('resize', handleResize);
    };
  });
  return width;
});

/***/ }),

/***/ "./utils/tools.js":
/*!************************!*\
  !*** ./utils/tools.js ***!
  \************************/
/*! exports provided: objectifyForm, isJSON, numberSeparator, removeSeparator, forceNumeric, forceNumeric4, forceNumeric6, forceNumeric10, fixNumbers, convertNumber, checkPersianWord, forceLetter, secondsToMs, getDistance, EMAIL_RX, Mobile_RX, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "objectifyForm", function() { return objectifyForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isJSON", function() { return isJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "numberSeparator", function() { return numberSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeSeparator", function() { return removeSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric", function() { return forceNumeric; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric4", function() { return forceNumeric4; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric6", function() { return forceNumeric6; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceNumeric10", function() { return forceNumeric10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fixNumbers", function() { return fixNumbers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertNumber", function() { return convertNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkPersianWord", function() { return checkPersianWord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forceLetter", function() { return forceLetter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "secondsToMs", function() { return secondsToMs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDistance", function() { return getDistance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_RX", function() { return EMAIL_RX; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Mobile_RX", function() { return Mobile_RX; });
// Convert Form Array To json
var objectifyForm = function objectifyForm(formArray) {
  //serialize data function
  var returnArray = {};

  for (var i = 0; i < formArray.length; i++) {
    returnArray[formArray[i]['name']] = formArray[i]['value'];
  }

  return returnArray;
}; // Check string is json or not

var isJSON = function isJSON(str) {
  try {
    return JSON.parse(str) && !!str;
  } catch (e) {
    return false;
  }
}; // Add comma Separator to digit number

var numberSeparator = function numberSeparator(num, sep) {
  var number = removeSeparator(num).toString(),
      separator = typeof sep === 'undefined' ? ',' : sep;
  return number.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + separator);
}; // Remove comma seprator From digit number

var removeSeparator = function removeSeparator(num, sep) {
  var separator = typeof sep === 'undefined' ? ',' : sep;
  var re = new RegExp(separator, 'g');
  return num.toString().replace(re, '');
}; // Convert elemetn's value for remove all characters exept number, Just Allow Type Numbers

var forceNumeric = function forceNumeric(e) {
  //let $input = e.replace(/[^\d]+/g, '');
  var $input = e.replace(/[^0-9۰-۹]+/g, '');
  return $input;
}; // Just Allow 4 number

var forceNumeric4 = function forceNumeric4(e) {
  var $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 4) {
    $input = $input.substring(0, 4);
  }

  return $input;
}; // Just Allow 6 number

var forceNumeric6 = function forceNumeric6(e) {
  var $input = e; //$input.replace(/[^\d]+/g, '');

  $input.replace(/[^0-9۰-۹]+/g, '');

  if ($input.length > 6) {
    $input = $input.substring(0, 6);
  }

  return $input;
}; // Just Allow 10 number

var forceNumeric10 = function forceNumeric10(e) {
  var $input = e;
  $input.replace(/[^\d]+/g, '');

  if ($input.length > 10) {
    $input = $input.substring(0, 10);
  }

  return $input;
}; // Convert Persian & Arabic number to English

var persianNumbersExp = [/۰/g, /۱/g, /۲/g, /۳/g, /۴/g, /۵/g, /۶/g, /۷/g, /۸/g, /۹/g];
var arabicNumbersExp = [/٠/g, /١/g, /٢/g, /٣/g, /٤/g, /٥/g, /٦/g, /٧/g, /٨/g, /٩/g];
var englishNumbersExp = [/0/g, /1/g, /2/g, /3/g, /4/g, /5/g, /6/g, /7/g, /8/g, /9/g];
var persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
var fixNumbers = function fixNumbers(str) {
  str = str.toString();

  if (typeof str === 'string') {
    for (var i = 0; i < 10; i++) {
      str = str.replace(persianNumbersExp[i], i).replace(arabicNumbersExp[i], i);
    }
  }

  return str;
}; // Convert  English number to Persian

var convertNumber = function convertNumber(str) {
  str = str.toString();

  if (typeof str === 'string') {
    for (var i = 0; i < 10; i++) {
      str = str.replace(englishNumbersExp[i], persianNumbers[i]);
    }
  }

  return str;
}; // Check if value Start (^) with a Persian word

var checkPersianWord = function checkPersianWord(string) {
  if (!/^[پچجحخهعغفقثصضشسیبلاتنمکگوئدذرزطظژؤإأءًٌٍَُِّ\s\n\r\t\d\(\)\[\]\{\}.,،;\-؛]+$/.test(string)) {//console.log('با کلمه فارسی شروع نشده');
  } else {//console.log('با کلمه فارسی شروع شده');
    }
}; // Don't Allow Specials Characters and numbers to type and replace them with remove, Work Fine

var forceLetter = function forceLetter(e) {
  var $input = e;
  $input.replace(/\d/g, '');
  $input.replace(/[&\/\\#,@@|+=!-_()$~%.'":*؟،×÷?<>{}]/g, ''); //$input.replace(/\s/g,'');       // space

  return $input;
}; // Convert Second to M:S

var secondsToMs = function secondsToMs(d) {
  d = Number(d);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);
  var mDisplay = m > 0 ? m + ':' : '00:';
  var sDisplay = s > 0 ? s : '00';
  return mDisplay + sDisplay;
}; // Calculate distance between 2 GPS coordinates in kilometer

var getDistance = function getDistance(lat1, lon1, lat2, lon2) {
  var degreesToRadians = function degreesToRadians(degrees) {
    return degrees * Math.PI / 180;
  };

  var earthRadiusKm = 6371;
  var dLat = degreesToRadians(lat2 - lat1);
  var dLon = degreesToRadians(lon2 - lon1);
  lat1 = degreesToRadians(lat1);
  lat2 = degreesToRadians(lat2);
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return earthRadiusKm * c;
}; // Email Validation Regex

var EMAIL_RX = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,64}/; // Moible Validation Regex

var Mobile_RX = /(\+98|0|98|0098)?([ ]|-|[()]){0,2}9[0-9]([ ]|-|[()]){0,2}(?:[0-9]([ ]|-|[()]){0,2}){8}/;
/* harmony default export */ __webpack_exports__["default"] = (numberSeparator);

/***/ })

}]);
//# sourceMappingURL=2.js.map