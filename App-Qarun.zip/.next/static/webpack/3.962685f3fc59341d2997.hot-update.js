webpackHotUpdate(3,{

/***/ "./components/UserSuggest/User.js":
/*!****************************************!*\
  !*** ./components/UserSuggest/User.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _WindowsWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../WindowsWidth */ "./components/WindowsWidth.js");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




var User = function User(props) {
  var width = Object(_WindowsWidth__WEBPACK_IMPORTED_MODULE_2__["default"])();
  var userClass = width > 992 ? 'col-1' : width > 400 ? 'col-2' : 'col-3';
  return __jsx("div", {
    className: 'userClass'
  }, __jsx(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
    href: "/user/".concat(props.userName),
    passHref: true
  }, __jsx("a", {
    className: "mr-2 user_link"
  }, __jsx("img", {
    src: props.image,
    alt: props.alt,
    className: "rounded-circle img-thumbnail"
  }))), __jsx("p", {
    className: "text-truncate"
  }, props.userName));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(User));

/***/ })

})
//# sourceMappingURL=3.962685f3fc59341d2997.hot-update.js.map