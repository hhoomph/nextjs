import React from 'react';
import Nav from '../components/Nav/Nav';
import Counters from '../components/Counter/Counters';
import { ReactComponent as Logo } from '../public/static/img/logo.svg';
import Loader from '../components/Loader/Loader';
function App() {
  return (
    <>
      <Nav />
      <header className="App_header">
        <Logo className="App-logo mt-1" />
      </header>
      <Counters />
      <Loader loader_use="audio" loader_size="30" loader_color="#4c2b3c" />
    </>
  );
}
export default App;